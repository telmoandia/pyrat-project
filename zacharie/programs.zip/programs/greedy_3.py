#####################################################################################################################################################
######################################################################## INFO #######################################################################
#####################################################################################################################################################

"""
    This program is an empty PyRat program file.
    It serves as a template for your own programs.
    Some [TODO] comments below are here to help you keep your code organized.
    Note that all PyRat programs must have a "turn" function.
    Functions "preprocessing" and "postprocessing" are optional.
    Please check the documentation of these functions for more info on their purpose.
    Also, the PyRat website gives more detailed explanation on how a PyRat game works.
    https://formations.imt-atlantique.fr/pyrat
"""

#####################################################################################################################################################
###################################################################### IMPORTS ######################################################################
#####################################################################################################################################################

# Import PyRat
from pyrat import *

# External imports 
import heapq

# Previously developed functions
from tsp_1 import *
import greedy_4 as opponent

#####################################################################################################################################################
############################################################### CONSTANTS & VARIABLES ###############################################################
#####################################################################################################################################################

#####################################################################################################################################################
##################################################################### FUNCTIONS #####################################################################
#####################################################################################################################################################

def short_traversal ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]]
              ) ->                  Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Traversal function that explores a graph from a given vertex.
        This function is generic and can be used for most graph traversal.
        To adapt it to a specific traversal, you need to provide the adapted functions to create, push and pop elements from the structure.
        In:
            * source:             Vertex from which to start the traversal.
            * graph:              Graph on which to perform the traversal.
            * create_structure:   Function that creates an empty structure to use in the traversal.
            * push_to_structure:  Function that adds an element of type B to the structure of type A.
            * pop_from_structure: Function that returns and removes an element of type B from the structure of type A.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """

    distances_to_explored_vertices = {}
    priority_queue = create_structure()
    routing_table = {}

    # Adding the first element inside of the structures
    push_to_structure(priority_queue,(source,None))
    distances_to_explored_vertices[source] = 0
    
    while len(priority_queue) > 0:
        (element, parent) = pop_from_structure(priority_queue)
        routing_table[element] = parent

        # We update the distances and parents of the neighbours if needed
        for neighbour in graph[element].keys():
            if neighbour in distances_to_explored_vertices.keys():
                if distances_to_explored_vertices[neighbour] > distances_to_explored_vertices[element] + graph[element][neighbour]:
                    distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
            else:
                distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                if distances_to_explored_vertices[neighbour] < 11:
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
                
    
    return distances_to_explored_vertices, routing_table

def short_dijkstra ( source: int,
               graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]]
             ) ->      Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Dijkstra algorithm that only explores vertices that are at a distance under 8 from the beginning vertice
        In:
            * source: Vertex from which to start the traversal.
            * graph:  Graph on which to perform the traversal.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """
    
    # Function to create an empty priority queue
    def _create_structure ():
        priority_queue = []
        return priority_queue
                
    # Function to add an element to the priority queue
    def _push_to_structure (structure, element):
        heapq.heappush(structure, element)
        pass
        
    # Function to extract an element from the priority queue
    def _pop_from_structure (structure):
        return heapq.heappop(structure)
    
    # Perform the traversal
    distances_to_explored_vertices, routing_table = short_traversal(source, graph, _create_structure, _push_to_structure, _pop_from_structure)
    return distances_to_explored_vertices, routing_table

def focused_traversal ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                target:             int,
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]]
              ) ->                  Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Traversal function that explores a graph from a given vertex.
        This function is generic and can be used for most graph traversal.
        To adapt it to a specific traversal, you need to provide the adapted functions to create, push and pop elements from the structure.
        In:
            * source:             Vertex from which to start the traversal.
            * graph:              Graph on which to perform the traversal.
            * create_structure:   Function that creates an empty structure to use in the traversal.
            * push_to_structure:  Function that adds an element of type B to the structure of type A.
            * pop_from_structure: Function that returns and removes an element of type B from the structure of type A.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """

    distances_to_explored_vertices = {}
    priority_queue = create_structure()
    routing_table = {}

    # Adding the first element inside of the structures
    push_to_structure(priority_queue,(source,None))
    distances_to_explored_vertices[source] = 0
    
    while len(priority_queue) > 0:
        (element, parent) = pop_from_structure(priority_queue)
        routing_table[element] = parent

        # We update the distances and parents of the neighbours if needed
        for neighbour in graph[element].keys():
            if neighbour in distances_to_explored_vertices.keys():
                if distances_to_explored_vertices[neighbour] > distances_to_explored_vertices[element] + graph[element][neighbour]:
                    distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
            else:
                distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                if neighbour == target:
                    break
                push_to_structure(priority_queue, (neighbour, element))
                routing_table[neighbour] = element
    
    return distances_to_explored_vertices, routing_table

def focused_dijkstra ( source: int,
                    graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                    target:    int
                    ) ->      Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Dijkstra algorithm that stops once the target is found
        In:
            * source: Vertex from which to start the traversal.
            * graph:  Graph on which to perform the traversal.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """
    
    # Function to create an empty priority queue
    def _create_structure ():
        priority_queue = []
        return priority_queue
                
    # Function to add an element to the priority queue
    def _push_to_structure (structure, element):
        heapq.heappush(structure, element)
        pass
        
    # Function to extract an element from the priority queue
    def _pop_from_structure (structure):
        return heapq.heappop(structure)
    
    # Perform the traversal
    distances_to_explored_vertices, routing_table = focused_traversal(source, graph, target, _create_structure, _push_to_structure, _pop_from_structure)
    return distances_to_explored_vertices, routing_table

##dico = {1: {2: 7, 3: 4, 4: 3}, 2: {1: 7, 3: 8, 4: 2}, 3: {1: 4, 2: 8, 4: 1}, 4: {1: 3, 2: 2, 3: 1}}
##print(greedy(dico,1))

def give_score ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                current_vertex: int,
                targets:        List[int]
            ) ->              Tuple[List[float], Dict[int, Union[None, int]]]:
    """
        Function that associates a score to each target.
        In:
            * graph:          Graph containing the vertices.
            * current_vertex: Current location of the player in the maze.
            
        Out:
            * scores:        Scores given to the targets.
    """

    scores = {}
    
    for cheese in targets:
        scores[cheese] = 0
        # We determine the number of cheeses in a distance under 8 from each piece of cheese
        distances_to_explored_vertices, routing_table = short_dijkstra(cheese, graph)

        # Each cheese in a distance under 11 counts as one point for the score
        for cheese_1 in targets:
            if (cheese_1 != cheese) and (cheese_1 in distances_to_explored_vertices.keys()):
                scores[cheese] += 1 - distances_to_explored_vertices[cheese_1]/11

        distances_to_explored_vertices, routing_table = focused_dijkstra(current_vertex, graph, cheese)
        if distances_to_explored_vertices[cheese] <= 2:
            scores[cheese] = 1000 - distances_to_explored_vertices[cheese]
        else:
            scores[cheese] -= distances_to_explored_vertices[cheese]/10

    return scores

def best_cheese ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
             initial_vertex: int,
             targets:        List[int]
           ) ->              List[int]:
    
    """
        Greedy algorithm that determines the optimal piece of cheese to go to.
        In:
            * graph:          Maze
            * initial_vertex: Initial location of the player in the maze.
            * targets:        List of cheeses
        Out:
            * optimal: Optimal cheese to go to at a given moment.
    """

    route = [initial_vertex]

    scores = give_score(graph, initial_vertex, targets)

    # We order the scores in decreasing value
    sorted_scores = {cheese: scores[cheese] for cheese in sorted(scores, key=scores.get, reverse=True)}

    for cheese in sorted_scores.keys():
        route.append(cheese)

    return route

        
#####################################################################################################################################################
##################################################### EXECUTED ONCE AT THE BEGINNING OF THE GAME ####################################################
#####################################################################################################################################################

def preprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                    maze_width:       int,
                    maze_height:      int,
                    name:             str,
                    teams:            Dict[str, List[str]],
                    player_locations: Dict[str, int],
                    cheese:           List[int],
                    possible_actions: List[str],
                    memory:           threading.local
                  ) ->                None:

    """
        This function is called once at the beginning of the game.
        It is typically given more time than the turn function, to perform complex computations.
        Store the results of these computations in the provided memory to reuse them later during turns.
        To do so, you can crete entries in the memory dictionary as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """
    """"Problèmes car la route doit être calculée à chaque tour et non pas au tout début(pour ça que
        on retire dans action des trucs qui ne devraient pas être retirés. Il faut réutiliser en plus 
        le modèle de greedy_2)"""
    
    pass
    
#####################################################################################################################################################
######################################################### EXECUTED AT EACH TURN OF THE GAME #########################################################
#####################################################################################################################################################

def turn ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
           maze_width:       int,
           maze_height:      int,
           name:             str,
           teams:            Dict[str, List[str]],
           player_locations: Dict[str, int],
           player_scores:    Dict[str, float],
           player_muds:      Dict[str, Dict[str, Union[None, int]]],
           cheese:           List[int],
           possible_actions: List[str],
           memory:           threading.local
         ) ->                str:

    """
        This function is called at every turn of the game and should return an action within the set of possible actions.
        You can access the memory you stored during the preprocessing function by doing memory.my_key.
        You can also update the existing memory with new information, or create new entries as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * action: One of the possible actions, as given in possible_actions.
    """

    player_pos = player_locations[name]

    # We create a complete graph of the cheeses and the initial position in our maze
    complete_graph, routing_tables = graph_to_metagraph(maze, [player_pos] + cheese)

    # We apply greedy to the complete graph to get the shortest route
    best = best_cheese(maze, player_pos, cheese)

    # We turn this best route in the complete graph in an actual route in the graph
    route = expand_route(best, routing_tables)

    # We turn this route into actions and store them in the memory
    actions = locations_to_actions(route, maze_width)
    
    return actions.pop(0)

#####################################################################################################################################################
######################################################## EXECUTED ONCE AT THE END OF THE GAME #######################################################
#####################################################################################################################################################

def postprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                     maze_width:       int,
                     maze_height:      int,
                     name:             str,
                     teams:            Dict[str, List[str]],
                     player_locations: Dict[str, int],
                     player_scores:    Dict[str, float],
                     player_muds:      Dict[str, Dict[str, Union[None, int]]],
                     cheese:           List[int],
                     possible_actions: List[str],
                     memory:           threading.local,
                     stats:            Dict[str, Any],
                   ) ->                None:

    """
        This function is called once at the end of the game.
        It is not timed, and can be used to make some cleanup, analyses of the completed game, model training, etc.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """

    # [TODO] Write your postprocessing code here
    pass
    
#################################################################################################################
###################################################### GO ! #####################################################
#################################################################################################################

""""Greedy_3 alone"""
# if __name__ == "__main__":
    
#     # Map the functions to the character
#     players = [{"name": "greedy 1", "preprocessing_function": preprocessing, "turn_function": turn}]
    
#     # Customize the game elements
#     config = {"maze_width": 31,
#               "maze_height": 29,
#               "mud_percentage": 40.0,
#               "nb_cheese": 5,
#               "trace_length": 1000}
    
#     # Start the game
#     game = PyRat(players, **config)
#     stats = game.start()
    
#     # Show statistics
#     print(stats)

"""Greedy_3 vs. Greedy_2"""
if __name__ == "__main__":

    # Map the functions to the character
    players = [{"name": "Greedy_3",
                  "team": "You",
                  "skin": "rat",
                  "preprocessing_function": preprocessing,
                  "turn_function": turn,
                  "postprocessing_function": postprocessing},
               {"name": "Greedy_2", 
                  "team": "Opponent",
                  "skin": "python",
                  "preprocessing_function": opponent.preprocessing if "preprocessing" in dir(opponent) else None,
                  "turn_function": opponent.turn,
                  "postprocessing_function": opponent.postprocessing if "postprocessing" in dir(opponent) else None}]
    
    # Customize the game elements
    config = {"maze_width": 31,
              "maze_height": 29,
              "mud_percentage": 20.0,
              "nb_cheese": 41}
    
    # Start the game
    game = PyRat(players, **config)
    stats = game.start()

    # Show statistics
    print(stats)
    
#################################################################################################################
#################################################################################################################
