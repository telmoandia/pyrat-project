#####################################################################################################################################################
######################################################################## INFO #######################################################################
#####################################################################################################################################################

"""
    This program is an empty PyRat program file.
    It serves as a template for your own programs.
    Some [TODO] comments below are here to help you keep your code organized.
    Note that all PyRat programs must have a "turn" function.
    Functions "preprocessing" and "postprocessing" are optional.
    Please check the documentation of these functions for more info on their purpose.
    Also, the PyRat website gives more detailed explanation on how a PyRat game works.
    https://formations.imt-atlantique.fr/pyrat
"""

#####################################################################################################################################################
###################################################################### IMPORTS ######################################################################
#####################################################################################################################################################

# Import PyRat
from pyrat import *

# External imports 
import heapq

# Previously developed functions

#####################################################################################################################################################
############################################################### CONSTANTS & VARIABLES ###############################################################
#####################################################################################################################################################

#####################################################################################################################################################
##################################################################### FUNCTIONS #####################################################################
#####################################################################################################################################################

def traversal ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]]
              ) ->                  Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Traversal function that explores a graph from a given vertex.
        This function is generic and can be used for most graph traversal.
        To adapt it to a specific traversal, you need to provide the adapted functions to create, push and pop elements from the structure.
        In:
            * source:             Vertex from which to start the traversal.
            * graph:              Graph on which to perform the traversal.
            * create_structure:   Function that creates an empty structure to use in the traversal.
            * push_to_structure:  Function that adds an element of type B to the structure of type A.
            * pop_from_structure: Function that returns and removes an element of type B from the structure of type A.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """

    distances_to_explored_vertices = {}
    priority_queue = create_structure()
    routing_table = {}

    # Adding the first element inside of the structures
    push_to_structure(priority_queue,(source,None))
    distances_to_explored_vertices[source] = 0
    
    while len(priority_queue) > 0:
        (element, parent) = pop_from_structure(priority_queue)
        routing_table[element] = parent

        # We update the distances and parents of the neighbours if needed
        for neighbour in graph[element].keys():
            if neighbour in distances_to_explored_vertices.keys():
                if distances_to_explored_vertices[neighbour] > distances_to_explored_vertices[element] + graph[element][neighbour]:
                    distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
            else:
                distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                push_to_structure(priority_queue, (neighbour, element))
                routing_table[neighbour] = element
                
    
    return distances_to_explored_vertices, routing_table

def dijkstra ( source: int,
               graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]]
             ) ->      Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Dijkstra's algorithm is a particular traversal where vertices are explored in an order that is proportional to the distance to the source vertex.
        In:
            * source: Vertex from which to start the traversal.
            * graph:  Graph on which to perform the traversal.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """
    
    # Function to create an empty priority queue
    def _create_structure ():
        priority_queue = []
        return priority_queue
                
    # Function to add an element to the priority queue
    def _push_to_structure (structure, element):
        heapq.heappush(structure, element)
        pass
        
    # Function to extract an element from the priority queue
    def _pop_from_structure (structure):
        return heapq.heappop(structure)
    
    # Perform the traversal
    distances_to_explored_vertices, routing_table = traversal(source, graph, _create_structure, _push_to_structure, _pop_from_structure)
    return distances_to_explored_vertices, routing_table

def graph_to_metagraph ( graph:    Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                         vertices: List[int]
                       ) ->        Tuple[numpy.ndarray, Dict[int, Dict[int, Union[None, int]]]]:
    
    """
        Function to build a complete graph out of locations of interest in a given graph.
        In:
            * graph:    Graph containing the vertices of interest.
            * vertices: Vertices to use in the complete graph.
        Out:
            * complete_graph: Complete graph of the vertices of interest.
            * routing_tables: Dictionary of routing tables obtained by traversals used to build the complete graph.
    """
    
    complete_graph = {}
    routing_tables = {}

    for vertice in vertices:

        # We apply dijkstra to every vertice
        distances_to_explored_vertices, routing_tables[vertice] = dijkstra(vertice, graph)

        #We add all of the other vertices in the complete graph with the key of the vertice we're working on
        for cheese in vertices:
            if cheese != vertice:
                if vertice not in complete_graph.keys():
                    complete_graph[vertice] = {cheese: distances_to_explored_vertices[cheese]}
                else:
                    complete_graph[vertice][cheese] = distances_to_explored_vertices[cheese]

    return complete_graph, routing_tables

def find_route ( routing_table: Dict[int, Union[None, int]],
                source:        int,
                target:        int
                ) ->             List[int]:
    """
        Function to return a sequence of locations using a provided routing table.
        In:
            * routing_table: Routing table as obtained by the traversal.
            * source:        Vertex from which we start the route (should be the one matching the routing table).
            * target:        Target to reach using the routing table.
        Out:
            * route: Sequence of locations to reach the target from the source, as perfomed in the traversal.
    """

    route = []

    # We initialise the route
    vertice = target
    route.append(vertice)

    # We go through the routing_table to get to the source going from parent to parent
    while vertice != source:
        parent = routing_table[vertice]
        route.append(parent)
        vertice = parent

    # We reverse the route to make it start from the source
    route.reverse()
    
    return route

def expand_route ( route_in_complete_graph: List[int],
                   routing_tables:          Dict[int, Dict[int, Union[None, int]]],
                 ) ->                       List[int]:
    
    """
        Returns the route in the original graph corresponding to a route in the complete graph.
        In:
            * route_in_complete_graph: List of locations in the complete graph.
            * routing_tables:          Routing tables obtained when building the complete graph.
        Out:
            * route: Route in the original graph corresponding to the given one.
    """
    
    route = [find_route(routing_tables[route_in_complete_graph[0]], route_in_complete_graph[0], route_in_complete_graph[1])[0]]

    # We associate vertice by vertice the route in the complete graph to a route in the real graph
    for i in range(len(route_in_complete_graph) - 1):
        route += find_route(routing_tables[route_in_complete_graph[i]], route_in_complete_graph[i], route_in_complete_graph[i + 1])[1:]

    return route

def locations_to_action ( source:     int,
                          target:     int,
                          maze_width: int
                        ) ->          str: 

    """
        Function to transform two locations into an action to reach target from the source.
        In:
            * source:     Vertex on which the player is.
            * target:     Vertex where the character wants to go.
            * maze_width: Width of the maze in number of cells.
        Out:
            * action: Name of the action to go from the source to the target.
    """

    # Convert indices in row, col pairs
    source_row = source // maze_width
    source_col = source % maze_width
    target_row = target // maze_width
    target_col = target % maze_width
    
    # Check difference to get direction
    difference = (target_row - source_row, target_col - source_col)
    if difference == (0, 0):
        action = "nothing"
    elif difference == (0, -1):
        action = "west"
    elif difference == (0, 1):
        action = "east"
    elif difference == (1, 0):
        action = "south"
    elif difference == (-1, 0):
        action = "north"
    else:
        raise Exception("Impossible move from", source, "to", target)
    return action

def locations_to_actions ( locations:  List[int],
                           maze_width: int
                         ) ->          List[str]: 
    """
        Function to transform a list of locations into a list of actions to reach vertex i+1 from vertex i.
        In:
             * locations:  List of locations to visit in order.
             * maze_width: Width of the maze in number of cells.
        Out:
             * actions: Sequence of actions to visit the list of locations.
     """
        
    # We iteratively transform pairs of locations into the corresponding action
    actions = []
    for i in range(len(locations) - 1):
        action = locations_to_action(locations[i], locations[i + 1], maze_width)
        actions.append(action)
    return actions

def short_traversal ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]]
              ) ->                  Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Traversal function that explores to a distance of 13 from a given vertex.
        In:
            * source:             Vertex from which to start the traversal.
            * graph:              Graph on which to perform the traversal.
            * create_structure:   Function that creates an empty structure to use in the traversal.
            * push_to_structure:  Function that adds an element of type B to the structure of type A.
            * pop_from_structure: Function that returns and removes an element of type B from the structure of type A.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """

    distances_to_explored_vertices = {}
    priority_queue = create_structure()
    routing_table = {}

    # Adding the first element inside of the structures
    push_to_structure(priority_queue,(source,None))
    distances_to_explored_vertices[source] = 0
    
    while len(priority_queue) > 0:
        (element, parent) = pop_from_structure(priority_queue)
        routing_table[element] = parent

        # We update the distances and parents of the neighbours if needed
        for neighbour in graph[element].keys():
            if neighbour in distances_to_explored_vertices.keys():
                if distances_to_explored_vertices[neighbour] > distances_to_explored_vertices[element] + graph[element][neighbour]:
                    distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
            else:
                distances_to_explored_vertices[neighbour] = distances_to_explored_vertices[element] + graph[element][neighbour]
                if distances_to_explored_vertices[neighbour] < 14:
                    push_to_structure(priority_queue, (neighbour, element))
                    routing_table[neighbour] = element
                
    
    return distances_to_explored_vertices, routing_table

def short_dijkstra ( source: int,
               graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]]
             ) ->      Tuple[Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Dijkstra algorithm that only explores vertices that are at a distance under 14 from the beginning vertice
        In:
            * source: Vertex from which to start the traversal.
            * graph:  Graph on which to perform the traversal.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
    """
    
    # Function to create an empty priority queue
    def _create_structure ():
        priority_queue = []
        return priority_queue
                
    # Function to add an element to the priority queue
    def _push_to_structure (structure, element):
        heapq.heappush(structure, element)
        pass
        
    # Function to extract an element from the priority queue
    def _pop_from_structure (structure):
        return heapq.heappop(structure)
    
    # Perform the traversal
    distances_to_explored_vertices, routing_table = short_traversal(source, graph, _create_structure, _push_to_structure, _pop_from_structure)
    return distances_to_explored_vertices, routing_table

def give_score ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                current_vertex: int,
                targets:        List[int],
                densities:      Dict[int, Dict[int, Union[None, int]]]
            ) ->              Tuple[List[float], Dict[int, Union[None, int]]]:
    """
        Function that associates a score to each target.
        In:
            * graph:          Graph containing the vertices.
            * current_vertex: Current location of the player in the maze.
            * targets:        List of cheeses
            * densities:      Density of the cheeses
        Out:
            * scores:        Scores given to the targets.
    """

    scores = {}

    # We initialise the scores
    for cheese in targets:
        scores[cheese] = 0
    
    distances_to_explored_vertices, routing_table = dijkstra(current_vertex, graph)

    # We calculate the scores using the density and the distance to the current_vertex
    for cheese in densities.keys():
        for cheese_1 in densities[cheese]:
            scores[cheese] += 1 - densities[cheese][cheese_1]/14

        # We go towards a cheese if it's in a distance inferior or equal to 2 from our position
        if distances_to_explored_vertices[cheese] <= 2:
            scores[cheese] = 1000 - distances_to_explored_vertices[cheese]
        else:
            scores[cheese] -= distances_to_explored_vertices[cheese]/13

    return scores

def density(graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                targets:        List[int]
            ) ->              Dict[int, Dict[int, Union[None, int]]]:
    
    """Gives density of cheese around every cheese for a distance of 13.
    In:
            * graph:          Graph containing the vertices.
            * targets:        List of cheeses
        Out:
            * densities:        Density around every cheese."""
    
    densities = {}

    for cheese in targets:
        densities[cheese] = {}

        # We determine the number of cheeses in a distance inferior or equal to 13 from each piece of cheese
        distances_to_explored_vertices, routing_table = short_dijkstra(cheese, graph)

        # We add the distance of each cheese_1 to the cheese
        for cheese_1 in targets:
            if cheese_1 in distances_to_explored_vertices.keys():
                densities[cheese][cheese_1] = distances_to_explored_vertices[cheese_1]

    return densities


def best_cheese ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
             initial_vertex: int,
             targets:        List[int],
             densities:      Dict[int, Dict[int, Union[None, int]]]
           ) ->              List[int]:
    
    """
        Greedy algorithm that determines the optimal piece of cheese to go to.
        In:
            * graph:          Maze
            * initial_vertex: Initial location of the player in the maze.
            * targets:        List of cheeses
            * densities:      Density of the cheeses
        Out:
            * route: Optimal route to follow.
    """

    route = [initial_vertex]

    scores = give_score(graph, initial_vertex, targets, densities)

    # We order the scores in decreasing value
    sorted_scores = {cheese: scores[cheese] for cheese in sorted(scores, key=scores.get, reverse=True)}

    for cheese in sorted_scores.keys():
        route.append(cheese)

    return route

        
#####################################################################################################################################################
##################################################### EXECUTED ONCE AT THE BEGINNING OF THE GAME ####################################################
#####################################################################################################################################################

def preprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                    maze_width:       int,
                    maze_height:      int,
                    name:             str,
                    teams:            Dict[str, List[str]],
                    player_locations: Dict[str, int],
                    cheese:           List[int],
                    possible_actions: List[str],
                    memory:           threading.local
                  ) ->                None:

    """
        This function is called once at the beginning of the game.
        It is typically given more time than the turn function, to perform complex computations.
        Store the results of these computations in the provided memory to reuse them later during turns.
        To do so, you can crete entries in the memory dictionary as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """
    
    memory.densities = density(maze, cheese)
    
    pass
    
    
#####################################################################################################################################################
######################################################### EXECUTED AT EACH TURN OF THE GAME #########################################################
#####################################################################################################################################################

def turn ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
           maze_width:       int,
           maze_height:      int,
           name:             str,
           teams:            Dict[str, List[str]],
           player_locations: Dict[str, int],
           player_scores:    Dict[str, float],
           player_muds:      Dict[str, Dict[str, Union[None, int]]],
           cheese:           List[int],
           possible_actions: List[str],
           memory:           threading.local
         ) ->                str:

    """
        This function is called at every turn of the game and should return an action within the set of possible actions.
        You can access the memory you stored during the preprocessing function by doing memory.my_key.
        You can also update the existing memory with new information, or create new entries as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * action: One of the possible actions, as given in possible_actions.
    """

    player_pos = player_locations[name]

    # We create a complete graph of the cheeses and the initial position in our maze
    complete_graph, routing_tables = graph_to_metagraph(maze, [player_pos] + cheese)

    # We delete every cheese from the density that has been eaten in the previous turn 
    # Using a list comprehension to make a list of the cheeses to be deleted
    delete = [cheeses for cheeses in memory.densities if cheeses not in cheese]
 
    # We delete the cheeses
    for cheeses in delete:
        del memory.densities[cheeses]

    for cheeses in memory.densities:
        for cheeses_1 in delete:
            if cheeses_1 in memory.densities[cheeses].keys():
                del memory.densities[cheeses][cheeses_1]

    # We apply greedy to the maze to determine the best route to follow
    best = best_cheese(maze, player_pos, cheese, memory.densities)

    # We turn this best route in the complete graph in an actual route in the graph
    route = expand_route(best, routing_tables)

    # We turn this route into actions and store them in the memory
    actions = locations_to_actions(route, maze_width)
    
    return actions.pop(0)


#####################################################################################################################################################
######################################################## EXECUTED ONCE AT THE END OF THE GAME #######################################################
#####################################################################################################################################################

def postprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                     maze_width:       int,
                     maze_height:      int,
                     name:             str,
                     teams:            Dict[str, List[str]],
                     player_locations: Dict[str, int],
                     player_scores:    Dict[str, float],
                     player_muds:      Dict[str, Dict[str, Union[None, int]]],
                     cheese:           List[int],
                     possible_actions: List[str],
                     memory:           threading.local,
                     stats:            Dict[str, Any],
                   ) ->                None:

    """
        This function is called once at the end of the game.
        It is not timed, and can be used to make some cleanup, analyses of the completed game, model training, etc.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """

    pass
    
#################################################################################################################
###################################################### GO ! #####################################################
#################################################################################################################

if __name__ == "__main__":
    
    # Map the functions to the character
    players = [{"name": "greedy 1", "preprocessing_function": preprocessing, "turn_function": turn}]
    
    # Customize the game elements
    config = {"maze_width": 31,
              "maze_height": 29,
              "mud_percentage": 10.0,
              "nb_cheese": 41,
              "trace_length": 1000}
    
    # Start the game
    game = PyRat(players, **config)
    stats = game.start()
    
    # Show statistics
    print(stats)
    
#################################################################################################################
#################################################################################################################
