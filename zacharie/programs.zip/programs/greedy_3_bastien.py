#####################################################################################################################################################
######################################################################## INFO #######################################################################
#####################################################################################################################################################

"""
    This program is an empty PyRat program file.
    It serves as a template for your own programs.
    Some [TODO] comments below are here to help you keep your code organized.
    Note that all PyRat programs must have a "turn" function.
    Functions "preprocessing" and "postprocessing" are optional.
    Please check the documentation of these functions for more info on their purpose.
    Also, the PyRat website gives more detailed explanation on how a PyRat game works.
    https://formations.imt-atlantique.fr/pyrat
"""

#####################################################################################################################################################
###################################################################### IMPORTS ######################################################################
#####################################################################################################################################################

# Import PyRat
from pyrat import *


# External imports 
# [TODO] Put all your standard imports (numpy, random, os, heapq...) here

import numpy as np
import heapq
import greedy_4_final as opponent

# Previously developed functions
# [TODO] Put imports of functions you have developed in previous lessons here


#####################################################################################################################################################
############################################################### CONSTANTS & VARIABLES ###############################################################
#####################################################################################################################################################

# [TODO] It is good practice to keep all your constants and global variables in an easily identifiable section

#####################################################################################################################################################
##################################################################### FUNCTIONS #####################################################################
#####################################################################################################################################################

# [TODO] It is good practice to keep all developed functions in an easily identifiable section
def get_weight ( source: int,
                 target: int,
                 graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]]
               ) ->      List[int]:

    """
        Fuction to return the weight of the edge in the graph from the source to the target.
        Here we propose an implementation for all types handled by the PyRat game.
        The function assumes that both vertices exists in the maze and the target is a neighbor of the source.
        As above, it can be verified using `assert source in get_vertices(graph)` and `assert target in get_neighbors(source, graph)` but at some cost.
        In:
            * source: Source vertex in the graph.
            * target: Target vertex, assumed to be a neighbor of the source vertex in the graph.
            * graph:  Graph on which to get the weight from the source vertex to the target vertex.
        Out:
            * weight: Weight of the corresponding edge in the graph.
    """
    
    # If "maze_representation" option is set to "dictionary"
    if isinstance(graph, dict):
        weight = graph[source][target]
    
    # If "maze_representation" option is set to "matrix"
    elif isinstance(graph, numpy.ndarray):
        weight = graph[source, target]
    
    # Unhandled data type
    else:
        raise Exception("Unhandled graph type", type(graph))
    
    # Done
    return weight


def locations_to_action ( source:     int,
                          target:     int,
                          maze_width: int
                        ) ->          str: 

    """
        Function to transform two locations into an action to reach target from the source.
        In:
            * source:     Vertex on which the player is.
            * target:     Vertex where the character wants to go.
            * maze_width: Width of the maze in number of cells.
        Out:
            * action: Name of the action to go from the source to the target.
    """

    # Convert indices in row, col pairs
    source_row = source // maze_width
    source_col = source % maze_width
    target_row = target // maze_width
    target_col = target % maze_width
    
    # Check difference to get direction
    difference = (target_row - source_row, target_col - source_col)
    if difference == (0, 0):
        action = "nothing"
    elif difference == (0, -1):
        action = "west"
    elif difference == (0, 1):
        action = "east"
    elif difference == (1, 0):
        action = "south"
    elif difference == (-1, 0):
        action = "north"
    else:
        raise Exception("Impossible move from", source, "to", target)
    return action


def get_neighbors ( vertex: int,
                    graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]]
                  ) ->      List[int]:    
    # If "maze_representation" option is set to "dictionary"
    if isinstance(graph, dict):
        neighbors = list(graph[vertex].keys())

    # If "maze_representation" option is set to "matrix"
    elif isinstance(graph, numpy.ndarray):
        neighbors = graph[vertex].nonzero()[0].tolist()
    
    # Unhandled data type
    else:
        raise Exception("Unhandled graph type", type(graph))
    
    # Done
    return neighbors

def traversal_modifie ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]], k: int
              ) ->                  Tuple[List[int], Dict[int, int], Dict[int, Union[None, int]]]:
    """
        traversal_modifie does the same thing as traversal, except it only explores vetices at a distance inferior at k
    """
    #We create the queuing structure
    queuing_structure = create_structure() 
    #We add the source to our queuing structure
    push_to_structure(queuing_structure, (0, source, None))
    #Initialize the outputs
    explored_vertices = []
    routing_table = {}
    dico_distance = {}
    #Iterate while some vertices remain
    while len(queuing_structure) > 0:
        (distance, current_vertex, parent) = pop_from_structure(queuing_structure)
        if distance <= k:
            dico_distance[current_vertex] = distance
            if current_vertex not in explored_vertices:
                explored_vertices.append(current_vertex)
                routing_table[current_vertex] = parent
                for neighbor in get_neighbors(current_vertex, graph):
                    distance_through_current_vertex = distance + get_weight(current_vertex, neighbor, graph)
                    if neighbor not in explored_vertices:
                        push_to_structure(queuing_structure, (distance_through_current_vertex, neighbor, current_vertex))
        else:
            return explored_vertices, routing_table, dico_distance
    return explored_vertices, routing_table, dico_distance

def traversal ( source:             int,
                graph:              Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                create_structure:   Callable[[], Any],
                push_to_structure:  Callable[[Any, Tuple[int, int, int]], None],
                pop_from_structure: Callable[[Any], Tuple[int, int, int]]
              ) ->                  Tuple[List[int], Dict[int, int], Dict[int, Union[None, int]]]:
    """
        Traversal function that explores a graph from a given vertex.
        This function is generic and can be used for most graph traversal.
        To adapt it to a specific traversal, you need to provide the adapted functions to create, push and pop elements from the structure.
        In:
            * source:             Vertex from which to start the traversal.
            * graph:              Graph on which to perform the traversal.
            * create_structure:   Function that creates an empty structure to use in the traversal.
            * push_to_structure:  Function that adds an element of type B to the structure of type A.
            * pop_from_structure: Function that returns and removes an element of type B from the structure of type A.
        Out:
            * distances_to_explored_vertices: Dictionary where keys are explored vertices and associated values are the lengths of the paths to reach them.
            * routing_table:                  Routing table to allow reconstructing the paths obtained by the traversal.
            * explored_vertices: List of explored vertices
    """
    #We create the queuing structure
    queuing_structure = create_structure() 
    #We add the source to our queuing structure
    push_to_structure(queuing_structure, (0, source, None))
    #Initialize the outputs
    explored_vertices = []
    routing_table = {}
    dico_distance = {}
    #Iterate while some vertices remain
    while len(queuing_structure) > 0:
        (distance, current_vertex, parent) = pop_from_structure(queuing_structure)
        dico_distance[current_vertex] = distance
        if current_vertex not in explored_vertices:
            explored_vertices.append(current_vertex)
            routing_table[current_vertex] = parent
            for neighbor in get_neighbors(current_vertex, graph):
                distance_through_current_vertex = distance + get_weight(current_vertex, neighbor, graph)
                if neighbor not in explored_vertices:
                    push_to_structure(queuing_structure, (distance_through_current_vertex, neighbor, current_vertex))
    return explored_vertices, routing_table, dico_distance
                    
        
    
def dijkstra ( source: int,
          graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]],
        ) ->      Tuple[List[int], Dict[int, int], Dict[int, Union[None, int]]]:
    # Function to create an empty FIFO, encoded as a list
    def create_structure ():
        return []
    
    
    def push_to_structure (structure, element: (int, int, int)):
        est_dans_la_structure = False
        for i in range(len(structure)):
            if structure[i][1] == element[1]:
                est_dans_la_structure = True
                if element[0] < structure[i][0]:
                    del(structure[i])
                    heapq.heappush(structure, element)
        if est_dans_la_structure == False:
            heapq.heappush(structure, element)
        return structure
                    
    # Function to extract an element from the FIFO (elements exit by the beginning)
    def pop_from_structure(structure):
        element = heapq.heappop(structure)
        return element    
    # Perform the traversal
    distances_to_explored_vertices, routing_table, dico_distance = traversal(source, graph, create_structure, push_to_structure, pop_from_structure)
    return distances_to_explored_vertices, routing_table, dico_distance

def dijkstra_modifie ( source: int,
          graph:  Union[numpy.ndarray, Dict[int, Dict[int, int]]], k: int
        ) ->      Tuple[List[int], Dict[int, int], Dict[int, Union[None, int]]]:
    # Function to create an empty FIFO, encoded as a list
    def create_structure ():
        return []
    
    
    def push_to_structure (structure, element: (int, int, int)):
        est_dans_la_structure = False
        for i in range(len(structure)):
            if structure[i][1] == element[1]:
                est_dans_la_structure = True
                if element[0] < structure[i][0]:
                    del(structure[i])
                    heapq.heappush(structure, element)
        if est_dans_la_structure == False:
            heapq.heappush(structure, element)
        return structure
                    
    # Function to extract an element from the FIFO (elements exit by the beginning)
    def pop_from_structure(structure):
        element = heapq.heappop(structure)
        return element    
    # Perform the traversal
    distances_to_explored_vertices, routing_table, dico_distance = traversal_modifie(source, graph, create_structure, push_to_structure, pop_from_structure, k)
    return distances_to_explored_vertices, routing_table, dico_distance    


def find_route ( routing_table: Dict[int, Union[None, int]],
                 source:        int,
                 target:        int
               ) ->             List[int]:
    route = []
    vertice = target
    while routing_table[vertice] != None:
        route.append(vertice)
        vertice = routing_table[vertice]
    if routing_table[vertice] == None:
        route.append(vertice)
    route.reverse()
    return route

def locations_to_actions ( locations:  List[int],
                           maze_width: int
                         ) ->          List[str]: 
    """
        Function to transform a list of locations into a list of actions to reach vertex i+1 from vertex i.
        In:
            * locations:  List of locations to visit in order.
            * maze_width: Width of the maze in number of cells.
        Out:
            * actions: Sequence of actions to visit the list of locations.
    """
    
    # We iteratively transforms pairs of locations in the corresponding action
    actions = []
    for i in range(len(locations) - 1):
        action = locations_to_action(locations[i], locations[i + 1], maze_width)
        actions.append(action)
    return actions
        

def give_score ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                 current_vertex: int,
                 targets:        List[int]
               ) ->              Tuple[List[float], Dict[int, Union[None, int]]]:
    """
        Function that associates a score to each target.
        In:
            * graph:          Graph containing the vertices.
            * current_vertex: Current location of the player in the maze.
            
        Out:
            * scores:        Scores given to the targets.
            * routing_table: Routing table obtained from the current vertex.
    """
    n = len(targets)
    dico_distance_target = dict()
    explored_vertices, routing_table, dico_distance = dijkstra(current_vertex, graph)
    for vertices in targets:
        dico_distance_target[vertices] = (dico_distance[vertices])**2
        if dico_distance[vertices] <= 25:
            explored_vertice_cheese, routing_table_cheese, dico_distance_cheese = dijkstra_modifie(vertices, graph, 7)
            for cheese in targets:
                for explored in explored_vertice_cheese:
                    if cheese == explored:
                        dico_distance_target[vertices] = dico_distance_target[vertices] - 15
    return dico_distance_target, routing_table     

def greedy ( graph:          Union[numpy.ndarray, Dict[int, Dict[int, int]]],
             initial_vertex: int,
             vertices:       List[int]):
    """
        Greedy algorithm that goes to the score maximizer in a loop.
        In:
            * graph:          Graph containing the vertices.
            * initial_vertex: Initial location of the player in the maze.
            * vertices:       Vertices to visit with the greedy heuristic.
        Out:
            * route: Route to follow to perform the path through all vertices.
    """
    route = []
    vertice_temp = vertices.copy()
    closest_vertice = initial_vertex
    mini = np.inf
    while len(vertice_temp) > 0:
        mini = np.inf
        dico_distance_target, routing_table = give_score(graph, initial_vertex, vertice_temp)
        for sommet, distance in dico_distance_target.items():
            if distance < mini:
                closest_vertice = sommet
                mini = distance
        route = route + find_route(routing_table, initial_vertex, closest_vertice)
        vertice_temp.remove(closest_vertice)
        initial_vertex = closest_vertice
    return route
        
        
    
#####################################################################################################################################################
##################################################### EXECUTED ONCE AT THE BEGINNING OF THE GAME ####################################################
#####################################################################################################################################################

def preprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                    maze_width:       int,
                    maze_height:      int,
                    name:             str,
                    teams:            Dict[str, List[str]],
                    player_locations: Dict[str, int],
                    cheese:           List[int],
                    possible_actions: List[str],
                    memory:           threading.local
                  ) ->                None:

    """
        This function is called once at the beginning of the game.
        It is typically given more time than the turn function, to perform complex computations.
        Store the results of these computations in the provided memory to reuse them later during turns.
        To do so, you can crete entries in the memory dictionary as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """

    # [TODO] Write your preprocessing code here
    initial_vertex = player_locations[name]
    route = greedy (maze, initial_vertex, cheese)
    memory.action = locations_to_actions(route, maze_width)
    memory.fromage = cheese
    return memory.action
        
        
        
        
#####################################################################################################################################################
######################################################### EXECUTED AT EACH TURN OF THE GAME #########################################################
#####################################################################################################################################################

def turn ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
           maze_width:       int,
           maze_height:      int,
           name:             str,
           teams:            Dict[str, List[str]],
           player_locations: Dict[str, int],
           player_scores:    Dict[str, float],
           player_muds:      Dict[str, Dict[str, Union[None, int]]],
           cheese:           List[int],
           possible_actions: List[str],
           memory:           threading.local
         ) ->                str:

    """
        This function is called at every turn of the game and should return an action within the set of possible actions.
        You can access the memory you stored during the preprocessing function by doing memory.my_key.
        You can also update the existing memory with new information, or create new entries as memory.my_key = my_value.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * action: One of the possible actions, as given in possible_actions.
    """

    # [TODO] Write your turn code here and do not forget to return a possible action
    if cheese == memory.fromage:
        act = memory.action.pop(0)
        return act
    else:
        initial_vertex = player_locations[name]
        route = greedy (maze, initial_vertex, cheese)
        liste_actions = locations_to_actions(route, maze_width)
        act = liste_actions.pop(0)
        return act

#####################################################################################################################################################
######################################################## EXECUTED ONCE AT THE END OF THE GAME #######################################################
#####################################################################################################################################################

def postprocessing ( maze:             Union[numpy.ndarray, Dict[int, Dict[int, int]]],
                     maze_width:       int,
                     maze_height:      int,
                     name:             str,
                     teams:            Dict[str, List[str]],
                     player_locations: Dict[str, int],
                     player_scores:    Dict[str, float],
                     player_muds:      Dict[str, Dict[str, Union[None, int]]],
                     cheese:           List[int],
                     possible_actions: List[str],
                     memory:           threading.local,
                     stats:            Dict[str, Any],
                   ) ->                None:

    """
        This function is called once at the end of the game.
        It is not timed, and can be used to make some cleanup, analyses of the completed game, model training, etc.
        In:
            * maze:             Map of the maze, as data type described by PyRat's "maze_representation" option.
            * maze_width:       Width of the maze in number of cells.
            * maze_height:      Height of the maze in number of cells.
            * name:             Name of the player controlled by this function.
            * teams:            Recap of the teams of players.
            * player_locations: Locations for all players in the game.
            * player_scores:    Scores for all players in the game.
            * player_muds:      Indicates which player is currently crossing mud.
            * cheese:           List of available pieces of cheese in the maze.
            * possible_actions: List of possible actions.
            * memory:           Local memory to share information between preprocessing, turn and postprocessing.
        Out:
            * None.
    """

    # [TODO] Write your postprocessing code here
    pass
    
#####################################################################################################################################################
######################################################################## GO! ########################################################################
#####################################################################################################################################################

if __name__ == "__main__":

    # Map the functions to the character
    players = [{"name": "Greedy 3", "preprocessing_function": preprocessing, "turn_function": turn, "postprocessing_function": postprocessing, "skin":"python"}, {"name": "Greedy Zackarie", 
                  "team": "Opponent",
                  "skin": "ghost",
                  "preprocessing_function": opponent.preprocessing if "preprocessing" in dir(opponent) else None,
                  "turn_function": opponent.turn,
                  "postprocessing_function": opponent.postprocessing if "postprocessing" in dir(opponent) else None}]

    # Customize the game elements
    config = {"maze_width": 31,
              "maze_height": 29,
              "mud_percentage": 10.0,
              "nb_cheese": 41,
              "turn_time": 0.1}

    # Start the game
    game = PyRat(players, **config)
    stats = game.start()

    # Show statistics
    print(stats)

#####################################################################################################################################################
#####################################################################################################################################################
